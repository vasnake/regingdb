// BenchmarkCLR.cpp : main project file.

#include "stdafx.h"
#include <atlbase.h>
#include <time.h>

using namespace System;

int RunBenchmark(int * iCount, double * dAvgArea, int * iSeconds);

int main(array<System::String ^> ^args)
{

	int iCount, iElapsed, iRetCode;
	double dArea;
   String ^sMsg;

	iRetCode = RunBenchmark(&iCount, &dArea, &iElapsed);
   if (iRetCode == 2)
      Console::WriteLine(L"License checkout failed");
   else
   {
		sMsg = L"Count: " + iCount.ToString();
      Console::WriteLine(sMsg);
		sMsg = L"Avg Area: " + dArea.ToString();
      Console::WriteLine(sMsg);
		sMsg = L"Seconds: " + iElapsed.ToString();
      Console::WriteLine(sMsg);
   }
   Console::WriteLine(L"Hit any key to continue...");
   Console::ReadKey();
   return iRetCode;
}

#pragma managed(push, off)

int RunBenchmark(int * iCount, double * dAvgArea, int * iSeconds)
{

	HRESULT hr;
	IAoInitializePtr ipInit(CLSID_AoInitialize);	
	esriLicenseProductCode eProduct = esriLicenseProductCodeArcEditor;

	esriLicenseStatus licenseStatus = esriLicenseFailure;
	hr = ipInit->IsProductCodeAvailable(eProduct, &licenseStatus);
	if (licenseStatus == esriLicenseAvailable)
		hr = ipInit->Initialize(eProduct, &licenseStatus);
	if (licenseStatus != esriLicenseCheckedOut)
		return 2;

	IWorkspaceFactoryPtr ipWSF(CLSID_FileGDBWorkspaceFactory);
	IWorkspacePtr ipWS;
	IFeatureWorkspacePtr ipFWS;
	IFeatureClassPtr ipFClass;
	IFeatureCursorPtr ipFCursor;

	hr =ipWSF->OpenFromFile(CComBSTR("c:\\apps\\locator\\data\\azgas.gdb"), NULL, &ipWS);
	ipFWS = ipWS;
	hr = ipFWS->OpenFeatureClass(CComBSTR("parcel"), &ipFClass);
	hr = ipFClass->Search(NULL, VARIANT_TRUE, &ipFCursor);

	time_t tStart, tEnd;
	int iIntCount, iIntSeconds;
	double dArea, dTotalArea;
	IFeaturePtr ipFeat;
	IGeometryPtr ipShape;
	IAreaPtr ipArea;

	time(&tStart);
	iIntCount = 0;
	dTotalArea = 0;
	while (true)
	{
		hr = ipFCursor->NextFeature(&ipFeat);
		if (ipFeat == NULL)
			break;
		iIntCount++;
		hr = ipFeat->get_ShapeCopy(&ipShape);
		if (ipShape == NULL)
			continue;
		ipArea = ipShape;
		hr = ipArea->get_Area(&dArea);
		dTotalArea += dArea;
	}
	time(&tEnd);
	iIntSeconds = (int) (tEnd - tStart);

	*iCount = iIntCount;
	*dAvgArea = dTotalArea / (double) iIntCount;
	*iSeconds = iIntSeconds;

	return 0;

}

#pragma managed(pop)
