﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.Geometry;

namespace BenchmarkCS
{
	class Program
	{
		[STAThread] static void Main(string[] args)
		{
			IAoInitialize pInit = new AoInitializeClass();
			bool bSuccess = false;
			esriLicenseProductCode[] eProductList = new esriLicenseProductCode[] {esriLicenseProductCode.esriLicenseProductCodeArcEditor, esriLicenseProductCode.esriLicenseProductCodeArcView};
			foreach (esriLicenseProductCode eProduct in eProductList)
			{
				esriLicenseStatus eStatus = pInit.IsProductCodeAvailable(eProduct);
				if (eStatus != esriLicenseStatus.esriLicenseAvailable)
					continue;
				eStatus = pInit.Initialize(eProduct);
				if (eStatus != esriLicenseStatus.esriLicenseCheckedOut)
					continue;
				bSuccess = true;
				break;
			}
			if (! bSuccess)
			{
				Console.WriteLine("License checkout failed.");
				return;
			}

			string sPath = "c:/apps/locator/data/azgas.gdb";
			IWorkspaceFactory pWSF = new FileGDBWorkspaceFactoryClass();
			IFeatureWorkspace pFWS = (IFeatureWorkspace)pWSF.OpenFromFile(sPath, 0);
			IFeatureClass pFClass = pFWS.OpenFeatureClass("parcel");
			IFeatureCursor pFCursor = pFClass.Search(null, true);

			IFeature pFeat;
			IGeometry pShape;
			IArea pArea;
			DateTime dtStart = DateTime.Now;
			int iCount = 0;
			double dArea = 0;
			while (true)
			{
				pFeat = pFCursor.NextFeature();
				if (pFeat == null)
					break;
				iCount++;
				pShape = pFeat.ShapeCopy;
				if (pShape == null)
					continue;
				if (pShape.IsEmpty)
					continue;
				pArea = (IArea)pShape;
				dArea += pArea.Area;
				Marshal.ReleaseComObject(pArea);		// This is necessary to keep
				Marshal.ReleaseComObject(pShape);	// the program from crashing!
				//if (iCount % 100000 == 0)
				//   GC.Collect();
			}
			Marshal.ReleaseComObject(pFCursor);
			DateTime dtEnd = DateTime.Now;
			TimeSpan tsElapsed = dtEnd - dtStart;
			Console.WriteLine("RESULTS:");
			Console.WriteLine("Count: " + iCount.ToString());
			Console.WriteLine("Avg Area: " + ((int)(dArea / iCount)).ToString());
			Console.WriteLine("Seconds: " + tsElapsed.TotalSeconds.ToString());
			dArea = 0;
		}
	}
}
