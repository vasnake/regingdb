// BenchmarkJ.java

import java.io.IOException;
import java.util.Date;
import com.esri.arcgis.system.AoInitialize;
import com.esri.arcgis.system.EngineInitializer;
import com.esri.arcgis.system.esriLicenseProductCode;
import com.esri.arcgis.system.esriLicenseStatus;
import com.esri.arcgis.datasourcesGDB.FileGDBWorkspaceFactory;
import com.esri.arcgis.geodatabase.IWorkspace;
import com.esri.arcgis.geodatabase.IFeatureWorkspace;
import com.esri.arcgis.geodatabase.IFeatureClass;
import com.esri.arcgis.geodatabase.IFeatureCursor;
import com.esri.arcgis.geodatabase.IFeature;
import com.esri.arcgis.geometry.IGeometry;
import com.esri.arcgis.geometry.IArea;


public class BenchmarkJ
{
    public static void main(String[] args)
    {
        try
        {
            // Initialize the Java COM Interop.
            System.out.println("Initializing...");
            EngineInitializer.initializeEngine();

            // Initialize an ArcGIS license.
            AoInitialize aoInit = new AoInitialize();
            int iResult = aoInit.initialize(esriLicenseProductCode.esriLicenseProductCodeArcEditor);
            if (iResult != esriLicenseStatus.esriLicenseCheckedOut)
            {
                System.out.println("Could not get license.");
                return;
            }

            // Open feature class and cursor.
            System.out.println("Opening workspace...");
            String sPath = "C:/apps/Locator/Data/AZGas.gdb";
            FileGDBWorkspaceFactory WSF = new FileGDBWorkspaceFactory();
            IWorkspace pWS = WSF.openFromFile(sPath, 0);
            IFeatureWorkspace pFWS = (IFeatureWorkspace) pWS;
            System.out.println("Opening feature class...");
            IFeatureClass pFClass = pFWS.openFeatureClass("parcel");
            // int iNumRecs = pFClass.featureCount(null);
            // System.out.format("Count: %d\n", iNumRecs);
            System.out.println("Querying feature class...");
            IFeatureCursor pFCursor = pFClass.search(null, true);

            // Loop through records
            System.out.println("Looping through records...");
            int iCount = 0;
            double dArea = 0;
            Date dtStart = new Date();
            while (true)
            {
                IFeature pFeat = pFCursor.nextFeature();
                if (pFeat == null)
                {
                   break;
                }
                iCount++;
                IGeometry pShape = pFeat.getShapeCopy();
                if (pShape == null)
                {
                   continue;
                }
                if (pShape.isEmpty())
                {
                   continue;
                }
                IArea pArea = (IArea) pShape;
                dArea += pArea.getArea();
                pArea = null;
                pShape = null;
            }
            pFCursor = null;
            Date dtEnd = new Date();

            // Report results
            int iSec = (int) ((dtEnd.getTime() - dtStart.getTime()) / 1000);
            int iArea = (int) (dArea / iCount);
            System.out.println("RESULTS:");
            System.out.format("Count: %d\n", iCount);
            System.out.format("Avg Area: %d\n", iArea);
            System.out.format("Seconds: %d\n", iSec);

            // Release the license.
            aoInit.shutdown();
        }
        catch (IOException ex){
            System.out.println(ex.getMessage());
            System.out.println("App failed.");
        }
    } // End of method main

} // End of class:BenchmarkJ












