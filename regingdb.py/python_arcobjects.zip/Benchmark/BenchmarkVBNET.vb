Imports ESRI.ArcGIS.esriSystem
Imports ESRI.ArcGIS.Geodatabase
Imports ESRI.ArcGIS.DataSourcesGDB
Imports ESRI.ArcGIS.Geometry

Module Benchmark

	Sub Main()

		Dim pInit As IAoInitialize
		Dim eProduct As esriLicenseProductCode
		Dim eStatus As esriLicenseStatus
		Dim bSuccess As Boolean

		pInit = New AoInitialize
		bSuccess = False
		For Each eProduct In New esriLicenseProductCode() {esriLicenseProductCode.esriLicenseProductCodeArcEditor, esriLicenseProductCode.esriLicenseProductCodeArcView}
			eStatus = pInit.IsProductCodeAvailable(eProduct)
			If eStatus <> esriLicenseStatus.esriLicenseAvailable Then
				Continue For
			End If
			eStatus = pInit.Initialize(eProduct)
			If eStatus <> esriLicenseStatus.esriLicenseCheckedOut Then
				Continue For
			End If
			bSuccess = True
			Exit For
		Next
		If Not bSuccess Then
			Console.WriteLine("License checkout failed.")
			Exit Sub
		End If

		Dim sPath As String
		Dim pWSF As IWorkspaceFactory
		Dim pWS As IWorkspace
		Dim pFWS As IFeatureWorkspace
		Dim pFClass As IFeatureClass

		sPath = "c:\apps\locator\data\azgas.gdb"
		pWSF = New FileGDBWorkspaceFactory
		pWS = pWSF.OpenFromFile(sPath, 0)
		pFWS = pWS
		pFClass = pFWS.OpenFeatureClass("parcel")

		Dim pFCursor As IFeatureCursor
		Dim fStart As Single, fEnd As Single
		Dim iCount, iSeconds As Long
		Dim dArea As Double
		Dim pFeat As IFeature
		Dim pShape As IGeometry
		Dim pArea As IArea

		pFCursor = pFClass.Search(Nothing, True)
		fStart = Timer()
		iCount = 0
		dArea = 0
		Do
			pFeat = pFCursor.NextFeature
			If pFeat Is Nothing Then
				Exit Do
			End If
			iCount = iCount + 1
			pShape = pFeat.ShapeCopy
			If Not pShape Is Nothing Then
				pArea = pShape
				dArea = dArea + pArea.Area
			End If
		Loop
		fEnd = Timer()
		iSeconds = fEnd - fStart
		Console.WriteLine("RESULTS:")
		Console.WriteLine("Count: " & iCount)
		Console.WriteLine("Avg Area: " & CLng(dArea / iCount))
		Console.WriteLine("Seconds: " & iSeconds)

	End Sub

End Module
