# Benchmark.py

##import psyco
##psyco.full()

# Assumes that the following statements have been executed:
import sys
sys.path.append("c:\\apps\\Demo")
from Snippets import GetStandaloneModules, InitStandalone
GetStandaloneModules()
InitStandalone()

def DoIt():

    import time
    from comtypes.client import CreateObject

    import comtypes.gen.esriSystem as esriSystem
    import comtypes.gen.esriGeometry as esriGeometry
    import comtypes.gen.esriDataSourcesGDB as esriDataSourcesGDB
    import comtypes.gen.esriGeoDatabase as esriGeoDatabase

    print "Running..."
    sPath = "c:/apps/Locator/Data/AZGas.gdb"
    pWSF = CreateObject(esriDataSourcesGDB.FileGDBWorkspaceFactory, \
                        interface=esriGeoDatabase.IWorkspaceFactory)
    pWS = pWSF.OpenFromFile(sPath, 0)
    pFWS = pWS.QueryInterface(esriGeoDatabase.IFeatureWorkspace)
    pFClass = pFWS.OpenFeatureClass("parcel")
    pFCursor = pFClass.Search(None, True)
    dStart = time.clock()
    iCount = 0
    dArea = 0
    while True:
        pFeat = pFCursor.NextFeature()
        if not pFeat:
            break
        iCount += 1
        pShape = pFeat.ShapeCopy
        if not pShape:
            continue
        pArea = pShape.QueryInterface(esriGeometry.IArea)
        dArea += pArea.Area
        del pArea
        del pShape
    del pFCursor
    dEnd = time.clock()
    iSeconds = int(dEnd - dStart)
    print "RESULTS:"
    print "Count: %(#)d" % {"#": iCount}
    print "Avg Area: %(#)d" % {"#": dArea / iCount}
    print "Seconds: %(#)d" % {"#": iSeconds}

