# BenchmarkIron.py
# IronPython Example

import clr
clr.AddReference("ESRI.ArcGIS.System")
clr.AddReference("ESRI.ArcGIS.Geometry")
clr.AddReference("ESRI.ArcGIS.Geodatabase")
clr.AddReference("ESRI.ArcGIS.DataSourcesGDB")
import ESRI.ArcGIS.esriSystem as esriSystem
import ESRI.ArcGIS.Geometry as esriGeometry
import ESRI.ArcGIS.Geodatabase as esriGeodatabase
import ESRI.ArcGIS.DataSourcesGDB as esriDataSourcesGDB
import time

def InitStandalone():
    pInit = esriSystem.AoInitializeClass()
    eProduct = esriSystem.esriLicenseProductCode.esriLicenseProductCodeArcEditor
    eStatus = pInit.IsProductCodeAvailable(eProduct)
    if eStatus != esriSystem.esriLicenseStatus.esriLicenseAvailable:
        return False
    eStatus = pInit.Initialize(eProduct)
    return (eStatus == esriSystem.esriLicenseStatus.esriLicenseCheckedOut)

def DoIt():
    if not InitStandalone():
        print "Could not check out license."
        return
    print "Running..."
    sPath = "c:/apps/Locator/Data/AZGas.gdb"
    pWSF = esriDataSourcesGDB.FileGDBWorkspaceFactoryClass()
    pWS = pWSF.OpenFromFile(sPath, 0)
    pFC = esriGeodatabase.IFeatureWorkspace.OpenFeatureClass(pWS, "parcel")
    pFCursor = esriGeodatabase.IFeatureClass.Search(pFC, None, True)
    dStart = time.clock()
    iCount = 0
    dArea = 0
    while True:
        pFeat = esriGeodatabase.IFeatureCursor.NextFeature(pFCursor)
        if not pFeat:
            break
        iCount += 1
        pShape = esriGeodatabase.IFeature.ShapeCopy.GetValue(pFeat)
        if not pShape:
            continue
        dArea += esriGeometry.IArea.Area.GetValue(pShape)
        del pShape
    del pFCursor
    dEnd = time.clock()
    iSeconds = int(dEnd - dStart)
    print "RESULTS:"
    print "Count: %(#)d" % {"#": iCount}
    print "Avg Area: %(#)d" % {"#": dArea / iCount}
    print "Seconds: %(#)d" % {"#": iSeconds}
