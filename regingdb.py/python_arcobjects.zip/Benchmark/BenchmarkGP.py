# BenchmarkGP.py

import time
import arcgisscripting

print "Running..."
gp = arcgisscripting.create(9.3)
fc = "c:\\apps\\locator\\data\\azgas.gdb\\parcel"
desc = gp.describe(fc)
sf = desc.ShapeFieldName
rows = gp.searchcursor(fc, "", "", "", "")

dStart = time.clock()
iCount = 0
dArea = 0
while True:
    row = rows.next()
    if row == None:
        break
    iCount += 1
    if row.isnull(sf):
        continue
    shp = row.GetValue(sf)
    dArea += shp.area
dEnd = time.clock()
iSeconds = int(dEnd - dStart)
print "RESULTS:"
print "Count: %(#)d" % {"#": iCount}
print "Avg Area: %(#)d" % {"#": dArea / iCount}
print "Seconds: %(#)d" % {"#": iSeconds}

