// BenchmarkMFC.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "BenchmarkMFC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// The one and only application object

CWinApp theApp;

using namespace std;

int RunBenchmark(int * iCount, double * dAvgArea, int * iSeconds);

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		nRetCode = 1;
	}
	else
	{
		// TODO: code your application's behavior here.
		CoInitialize(NULL);
		int iCount, iElapsed;
		double dArea;
		nRetCode = RunBenchmark(&iCount, &dArea, &iElapsed);
		if (nRetCode == 2)
			_tprintf(_T("License checkout failed\n"));
		else
		{
			_tprintf(_T("Count: %i\n"), iCount);
			_tprintf(_T("Avg Area: %i\n"), (int) dArea);
			_tprintf(_T("Seconds: %i\n"), iElapsed);
		}
		_tprintf(_T("Hit any key to continue...\n"));
		_getwch();
		CoUninitialize();
	}

	return nRetCode;
}

int RunBenchmark(int * iCount, double * dAvgArea, int * iSeconds)
{

	HRESULT hr;
	IAoInitializePtr ipInit(CLSID_AoInitialize);	
	esriLicenseProductCode eProduct = esriLicenseProductCodeArcEditor;

	esriLicenseStatus licenseStatus = esriLicenseFailure;
	hr = ipInit->IsProductCodeAvailable(eProduct, &licenseStatus);
	if (licenseStatus == esriLicenseAvailable)
		hr = ipInit->Initialize(eProduct, &licenseStatus);
	if (licenseStatus != esriLicenseCheckedOut)
		return 2;

	IWorkspaceFactoryPtr ipWSF(CLSID_FileGDBWorkspaceFactory);
	IWorkspacePtr ipWS;
	IFeatureWorkspacePtr ipFWS;
	IFeatureClassPtr ipFClass;
	IFeatureCursorPtr ipFCursor;

	hr =ipWSF->OpenFromFile(CComBSTR("c:\\apps\\locator\\data\\azgas.gdb"), NULL, &ipWS);
	ipFWS = ipWS;
	hr = ipFWS->OpenFeatureClass(CComBSTR("parcel"), &ipFClass);
	hr = ipFClass->Search(NULL, VARIANT_TRUE, &ipFCursor);

	time_t tStart, tEnd;
	int iIntCount, iIntSeconds;
	double dArea, dTotalArea;
	IFeaturePtr ipFeat;
	IGeometryPtr ipShape;
	IAreaPtr ipArea;

	time(&tStart);
	iIntCount = 0;
	dTotalArea = 0;
	while (true)
	{
		hr = ipFCursor->NextFeature(&ipFeat);
		if (ipFeat == NULL)
			break;
		iIntCount++;
		hr = ipFeat->get_ShapeCopy(&ipShape);
		if (ipShape == NULL)
			continue;
		ipArea = ipShape;
		hr = ipArea->get_Area(&dArea);
		dTotalArea += dArea;
	}
	time(&tEnd);
	iIntSeconds = (int) (tEnd - tStart);

	*iCount = iIntCount;
	*dAvgArea = dTotalArea / (double) iIntCount;
	*iSeconds = iIntSeconds;

	return 0;

}
