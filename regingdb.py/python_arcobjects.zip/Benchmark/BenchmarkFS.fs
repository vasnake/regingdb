﻿// Learn more about F# at http://fsharp.net
#light

open System
open System.Runtime.InteropServices
open ESRI.ArcGIS.esriSystem
open ESRI.ArcGIS.DataSourcesGDB
open ESRI.ArcGIS.Geodatabase
open ESRI.ArcGIS.Geometry

let InitStandalone() = 
    let bResult = 
        let pInit = new AoInitializeClass()
        let eProduct = esriLicenseProductCode.esriLicenseProductCodeArcEditor
        let eStatus = pInit.IsProductCodeAvailable(eProduct)
        if eStatus <> esriLicenseStatus.esriLicenseAvailable then
            false
        else
            let eStatus = pInit.Initialize(eProduct)
            let bResult2 =
                if eStatus <> esriLicenseStatus.esriLicenseCheckedOut then
                    false
                else
                    true
            bResult2
    bResult
    
let DoIt() = 
    printfn "Running..."
    let sPath = "c:/apps/Locator/Data/AZGas.gdb"
    let pWSF = new FileGDBWorkspaceFactoryClass()
    let pWS = pWSF.OpenFromFile(sPath, 0)
    let pFWS = pWS :?> IFeatureWorkspace
    let pFC = pFWS.OpenFeatureClass("parcel")
    let pFCursor = pFC.Search(null, true)
    let mutable iCount = 0
    let mutable dArea = 0.0
    let mutable bLoop = true
    let dtStart = DateTime.Now
    while bLoop do
        let pFeat = pFCursor.NextFeature()
        if pFeat = null then
            bLoop <- false
        else
            iCount <- iCount + 1
            let pShape = pFeat.ShapeCopy
            if pShape <> null then
                if not pShape.IsEmpty then
                    let pArea = pShape :?> IArea
                    dArea <- dArea + pArea.Area
                    Marshal.ReleaseComObject(pArea) |> ignore
                Marshal.ReleaseComObject(pShape) |> ignore
    Marshal.ReleaseComObject(pFCursor) |> ignore
    let dtEnd = DateTime.Now
    let tsElapsed = dtEnd - dtStart
    printfn "RESULTS:"
    printfn "Count: %i" iCount
    printfn "Avg Area: %i" (int(dArea / double(iCount)))
    printfn "Seconds: %i" (int(tsElapsed.TotalSeconds))
    ()

[<STAThread>]
do
    if InitStandalone() then
        printfn "License obtained."
        DoIt()
    else
        printfn "Error obtaining license."
    
