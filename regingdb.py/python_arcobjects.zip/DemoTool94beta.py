# DemoTool94beta.py
#**** code changes for ArcGIS 9.4 beta 2 ****

import zipfile

def GetESRIConfigDir():
    sDir = "C:\\Program Files\\Common Files\\ArcGIS\\Desktop9.4\\Configuration\\CATID"
    return sDir
    
def GetESRIConfigFileName():
    sArc94ConfigDir = GetESRIConfigDir()
    sDemoToolLib_UUID = "{27722EEC-E805-4CE7-9239-45072B25D8C7}" # from DemoTool.idl
    sLibName = "DemoToolLib" # also from DemoTool.idl
    sName = sArc94ConfigDir + "\\" + sDemoToolLib_UUID.lower()
    sName += "_" + sLibName.lower() + ".ecfg"
    return sName

def RegisterCategory():
    # Create config.xml
    sXMLName = os.environ["TEMP"] + "\\config.xml"
    sMyUUID = CLSID(MyTool)
    sFileName = "c:\\apps\\Demo\\DemoTool\\DemoTool.tlb"
    sLine = '<?xml version="1.0"?>\n'
    sLine += '<ESRI.Configuration ver="1" FileName="' + sFileName + '">'
    sLine += '<Categories><Category CATID="' + sCATID_MxCommands + '">'
    sLine += '<Class CLSID="' + sMyUUID + '"/>'
    sLine += '</Category></Categories></ESRI.Configuration>\n'
    f = open(sXMLName, "w")
    f.write(sLine)
    f.flush()
    f.close()
    # Check if config dir exists
    sArc94ConfigDir = GetESRIConfigDir()
    if not os.path.exists(sArc94ConfigDir):
        os.makedirs(sArc94ConfigDir)
    # Create ecfg (zip) file
    sECFGName = GetESRIConfigFileName()
    z = zipfile.ZipFile(sECFGName, "w", zipfile.ZIP_DEFLATED)
    z.write(sXMLName, "config.xml")
    z.close()
    os.remove(sXMLName)
    return

def UnregisterCategory():
    sECFGName = GetESRIConfigFileName()
    if os.path.exists(sECFGName):
        os.remove(sECFGName)
    return

