# ToolHelper.py

def Status(sMsg, pos=-1, gp=None):
    if gp is None:
        print sMsg
    elif pos == -1:
        gp.setprogressorlabel(sMsg)
    elif pos == 0:
        gp.setprogressor("step", sMsg)
    else:        
        gp.setprogressorlabel(sMsg)
        gp.setprogressorposition(pos)

def Message(sMsg, gp=None):
    if gp is None:
        print sMsg
    else:
        gp.addmessage(sMsg)

def Error(sMsg, gp=None):
    if gp is None:
        print "ERROR: " + sMsg
    else:
        gp.adderror(sMsg)

def GetLibPath():
    """Return location of ArcGIS type libraries as string"""
    # return "C:/Program Files/ArcGIS/com/"
    import _winreg
    keyESRI = _winreg.OpenKey(_winreg.HKEY_LOCAL_MACHINE, \
                              "SOFTWARE\\ESRI\\ArcGIS")
    return _winreg.QueryValueEx(keyESRI, "InstallDir")[0] + "com\\"

def NewObj(MyClass, MyInterface):
    """Creates a new comtypes POINTER object where\n\
    MyClass is the class to be instantiated,\n\
    MyInterface is the interface to be assigned"""
    from comtypes.client import CreateObject
    try:
        ptr = CreateObject(MyClass, interface=MyInterface)
        return ptr
    except:
        return None

def CType(obj, interface):
    """Casts obj to interface and returns comtypes POINTER or None"""
    try:
        newobj = obj.QueryInterface(interface)
        return newobj
    except:
        return None
